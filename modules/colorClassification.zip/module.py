from NeuralModules.NeuralModule import NeuralModule
from keras import optimizers
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Convolution2D, MaxPooling2D
from PIL import Image
import numpy as np

class module(NeuralModule):
    def __init__(self):
        self.inputShape = (3,248,248)

    def createModel(self):
        print ("Generating model")
        model = Sequential()
        model.add(Convolution2D(32, 3, 3, init='glorot_normal',
                            input_shape=self.inputShape, dim_ordering='th', bias=True))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Activation('relu'))

        model.add(Convolution2D(32, 3, 3, init='glorot_normal',
                            dim_ordering='th', bias=True))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Activation('relu'))

        model.add(Convolution2D(32, 3, 3, init='glorot_normal',
                            dim_ordering='th', bias=True))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Activation('relu'))

        model.add(Convolution2D(32, 3, 3, init='glorot_normal',
                            dim_ordering='th', bias=True))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Activation('relu'))

        model.add(Convolution2D(32, 3, 3, init='glorot_normal',
                             dim_ordering='th', bias=True))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Activation('relu'))


        model.add(Flatten())
        model.add(Dense(25, init='uniform', bias=True))
        model.add(Activation('relu'))
        model.add(Dense(4))
        model.add(Activation('softmax'))

        model.compile(loss='categorical_crossentropy',
                  optimizer='adam',
                  metrics=['accuracy'])

        return model

    def inTransform(self, input):
        '''Input is an array of image file paths'''
        
        data = []
        for path in input:
            image = Image.open(path).convert('RGB')

            width, height = image.size  # Get dimensions

            minSize = min(width, height)

            left = (width - minSize) / 2
            top = (height - minSize) / 2
            right = (width + minSize) / 2
            bottom = (height + minSize) / 2
            # centercrop to square image. Then resize it to (imgWidth, imgHeight)
            image = image.crop((left, top, right, bottom))
            image = image.resize((248, 248), Image.NEAREST)

            # Convert to numpy array
            imgdata = np.asarray(image, dtype="uint8")

            # swap the last and color dimension, so the color dim comes first. (width, height, channel) -> (channel, width, height)
            imgdata = np.swapaxes(imgdata, 0, 2)
            data.append(imgdata)

        data = np.array(data).astype('float32')
        data /= 255
	print("in " + str(len(data)))
        return data

    def outTransform(self, rawOutput):
        '''Input is an array of image file paths'''
        return rawOutput

